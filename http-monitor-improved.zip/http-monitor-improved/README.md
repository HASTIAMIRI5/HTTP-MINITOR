# Http Monitor

A service that monitors URLs. For every registered URL it sends 10 HTTP GET
requests every few seconds and stores the status codes. When the number of
failed responses in the recent history reaches the URL's **threshold**, the URL
shows up in `/alerts`.

## Architecture

```
client ──▶ REST API ──▶ SQLite
              │
              ▼ (in-process channel)
          scheduler ──▶ NATS JetStream ──▶ worker(s) ──▶ 10 × GET ──▶ SQLite
```

* `server` – REST API + scheduler (publishes every monitored URL each `period` seconds).
* `worker` – receives jobs, probes the URL and stores the results. You can run several.
* On start the scheduler reloads all URLs from the database, so a restart does not stop monitoring.

## Requirements

* Go and a C compiler (SQLite driver uses cgo)
* A NATS server **with JetStream enabled**: `nats-server -js`

## Run

```
$ nats-server -js                                   # terminal 1
$ export HTTP_MONITOR_JWT_SECRET='some-long-random-string'
$ cd cmd/http-monitor && go build                   # build once
$ ./http-monitor server                             # terminal 2
$ ./http-monitor worker                             # terminal 3 (same directory: shares HttpMDB.db)
```

The server refuses to start without a real `HTTP_MONITOR_JWT_SECRET`.

## Configuration

Defaults live in `internal/app/http-monitor/config/default.go`. Any key can be
overridden with an environment variable: prefix `HTTP_MONITOR_`, dots become
underscores, e.g. `HTTP_MONITOR_SERVER_ADDRESS=:8080`.

| key | default | meaning |
|---|---|---|
| `server.address` | `:21345` | listen address |
| `jwt.secret` | *(must be set)* | token signing secret |
| `jwt.expiration` | `60` | token lifetime in minutes |
| `database.path` | `HttpMDB.db` | SQLite file (server and worker must use the same one) |
| `common.period` | `3` | seconds between two monitoring rounds |
| `common.requests` | `10` | HTTP requests per round per URL |
| `common.timeout` | `10` | seconds before one request is given up |
| `common.window` | `100` | how many most recent results are kept and counted |
| `common.workers` | `20` | URLs one worker checks at the same time |

## How results and alerts work

* Each round appends `common.requests` codes; only the newest `common.window` are kept.
* A result counts as **healthy only if it is 2xx**. A request that could not be
  completed (timeout, DNS error, connection refused) is stored as `0`.
* A URL is in alert when `failures in the window >= threshold`.

## Endpoints

Everything except `/register` and `/login` needs the token, sent either as a
`Token: <token>` header or `Authorization: Bearer <token>`.
Errors are returned as `{"error": "..."}`.

```
# register (201) – name required, password 8–72 chars; 409 if the name is taken
$ curl -X POST localhost:21345/register -H 'Content-Type: application/json' \
       -d '{"name":"ali","password":"a-good-password"}'

# login (200) – returns {"token": "..."}
$ curl -X POST localhost:21345/login -H 'Content-Type: application/json' \
       -d '{"name":"ali","password":"a-good-password"}'

# add a URL (201) – threshold is a number, optional (default 5), max = common.window
$ curl -X POST localhost:21345/request -H 'Content-Type: application/json' -H "Token: $TOKEN" \
       -d '{"url":"https://example.com","threshold":3}'

# all results: {"https://example.com":[200,200,...]}
$ curl localhost:21345/result -H "Token: $TOKEN"

# one URL
$ curl -X POST localhost:21345/result/url -H 'Content-Type: application/json' -H "Token: $TOKEN" \
       -d '{"url":"https://example.com"}'

# URLs currently in alert: {"https://example.com":true}
$ curl localhost:21345/alerts -H "Token: $TOKEN"
```

## Tests

```
$ go mod tidy && go test ./...
```
