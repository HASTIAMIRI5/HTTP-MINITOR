package server

import (
	"context"
	"errors"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/labstack/echo/v4"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	db "github.com/shirinebadi/http-monitor/internal/app/http-monitor/data/db"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/data/nats"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/handler"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/scheduler"
	"github.com/spf13/cobra"
)

// limitBody rejects request bodies bigger than n bytes.
func limitBody(n int64) echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			c.Request().Body = http.MaxBytesReader(c.Response(), c.Request().Body, n)
			return next(c)
		}
	}
}

func main(cfg config.Config) {
	if err := cfg.RequireSecureSecret(); err != nil {
		log.Fatal(err)
	}

	myDB, err := db.Init(cfg.Database.Path)
	if err != nil {
		log.Fatal("failed to setup db: ", err)
	}

	js, err := nats.New(cfg)
	if err != nil {
		log.Fatal("failed to setup nats: ", err)
	}

	store := &db.Mydb{DB: myDB}
	token := &handler.Token{Cfg: cfg}
	jobs := make(chan model.Status, 20)

	user := handler.UserHandler{UserI: store, Token: token}
	url := handler.UrlHandler{Cfg: cfg, StatusI: store, UrlI: store, Jobs: jobs}
	response := handler.ResponseHandler{StatusI: store, UrlI: store}

	sched := scheduler.New(cfg, jobs, &nats.Nats{Cfg: cfg, Cn: js}, store)
	go sched.Run()

	e := echo.New()
	e.HideBanner = true
	e.Use(limitBody(1 << 20)) // 1 MiB

	auth := token.Middleware()

	e.POST("/register", user.Register)
	e.POST("/login", user.Login)
	e.POST("/request", url.Send, auth)
	e.GET("/result", response.Get, auth)
	e.POST("/result/url", response.Post, auth)
	e.GET("/alerts", response.Alert, auth)

	go func() {
		if err := e.Start(cfg.Server.Address); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatal(err)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)
	<-quit

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := e.Shutdown(ctx); err != nil {
		log.Printf("shutdown: %v", err)
	}
}

func Register(root *cobra.Command, cfg config.Config) {
	runServer := &cobra.Command{
		Use:   "server",
		Short: "API server and scheduler of the http monitor",
		Run: func(cmd *cobra.Command, args []string) {
			main(cfg)
		},
	}

	root.AddCommand(runServer)
}
