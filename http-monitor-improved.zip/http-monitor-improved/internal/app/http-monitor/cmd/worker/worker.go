package worker

import (
	"io"
	"log"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	db "github.com/shirinebadi/http-monitor/internal/app/http-monitor/data/db"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/data/nats"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"github.com/spf13/cobra"
)

// checker probes URLs and stores the results.
type checker struct {
	cfg    config.Config
	store  *db.Mydb
	client *http.Client

	sem chan struct{}  // limits how many URLs are checked at once
	wg  sync.WaitGroup // lets us finish running checks on shutdown

	mu       sync.Mutex
	inflight map[uint64]struct{} // statuses being checked right now
}

func newChecker(cfg config.Config, store *db.Mydb) *checker {
	return &checker{
		cfg:      cfg,
		store:    store,
		client:   &http.Client{Timeout: time.Duration(cfg.Common.Timeout) * time.Second},
		sem:      make(chan struct{}, cfg.Common.Workers),
		inflight: make(map[uint64]struct{}),
	}
}

// begin marks id as in progress; false means a check for it is still running.
func (c *checker) begin(id uint64) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, busy := c.inflight[id]; busy {
		return false
	}
	c.inflight[id] = struct{}{}
	return true
}

func (c *checker) end(id uint64) {
	c.mu.Lock()
	delete(c.inflight, id)
	c.mu.Unlock()
}

// handle is called for every message. It never blocks on the actual HTTP
// requests, only (briefly) when all worker slots are busy.
func (c *checker) handle(s *model.Status, done func()) {
	if !c.begin(s.ID) {
		// The previous round for this URL is still running (slow site):
		// skip this tick instead of piling up and overwriting results.
		done()
		return
	}
	c.sem <- struct{}{}
	c.wg.Add(1)
	go func(id uint64) {
		defer c.wg.Done()
		defer func() { <-c.sem }()
		defer c.end(id)
		defer done() // ack only after the results are saved
		c.check(id)
	}(s.ID)
}

func (c *checker) check(id uint64) {
	status, err := c.store.GetFirst(id)
	if err != nil {
		log.Printf("worker: status %d: %v", id, err)
		return
	}
	target, err := c.store.SearchUrl(status.Url)
	if err != nil {
		log.Printf("worker: url %d of status %d: %v", status.Url, id, err)
		return
	}

	codes := c.probe(target.Body)
	status.AddResults(codes, c.cfg.Common.Window)
	status.Time = time.Now()

	// One write per round (instead of one per request).
	if err := c.store.Update(&status); err != nil {
		log.Printf("worker: saving status %d: %v", id, err)
	}
}

// probe sends cfg.Common.Requests concurrent GET requests and waits for all of
// them. Each goroutine writes its own slot, so no locking is needed.
func (c *checker) probe(target string) []int32 {
	codes := make([]int32, c.cfg.Common.Requests)
	var wg sync.WaitGroup
	for i := range codes {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			codes[i] = c.get(target)
		}(i)
	}
	wg.Wait()
	return codes
}

// get returns the HTTP status code, or 0 if the request itself failed
// (timeout, DNS error, connection refused...).
func (c *checker) get(target string) int32 {
	resp, err := c.client.Get(target)
	if err != nil {
		return 0
	}
	defer resp.Body.Close()
	_, _ = io.Copy(io.Discard, io.LimitReader(resp.Body, 1<<20))
	return int32(resp.StatusCode)
}

func main(cfg config.Config) {
	myDB, err := db.Init(cfg.Database.Path)
	if err != nil {
		log.Fatal("failed to setup db: ", err)
	}

	js, err := nats.New(cfg)
	if err != nil {
		log.Fatal("failed to setup nats: ", err)
	}

	chk := newChecker(cfg, &db.Mydb{DB: myDB})
	n := &nats.Nats{Cfg: cfg, Cn: js}

	sub, err := n.Subscribe(chk.handle)
	if err != nil {
		log.Fatal("failed to subscribe: ", err)
	}
	log.Println("worker started")

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)
	<-quit

	log.Println("worker stopping, waiting for running checks...")
	_ = sub.Unsubscribe()
	chk.wg.Wait()
}

func Register(root *cobra.Command, cfg config.Config) {
	runWorker := &cobra.Command{
		Use:   "worker",
		Short: "worker that probes the monitored urls",
		Run: func(cmd *cobra.Command, args []string) {
			main(cfg)
		},
	}

	root.AddCommand(runWorker)
}
