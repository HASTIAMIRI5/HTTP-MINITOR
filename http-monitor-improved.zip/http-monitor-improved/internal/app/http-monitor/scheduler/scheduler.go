package scheduler

import (
	"log"
	"sync"
	"time"

	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
)

// Publisher sends a status to the workers (implemented by the NATS layer).
type Publisher interface {
	Publish(s *model.Status) error
}

// Store gives the scheduler access to already registered URLs.
type Store interface {
	All() ([]model.Status, error)
}

type Scheduler struct {
	cfg  config.Config
	jobs <-chan model.Status
	pub  Publisher
	db   Store

	mu       sync.RWMutex
	statuses map[uint64]model.Status
}

func New(cfg config.Config, jobs <-chan model.Status, pub Publisher, store Store) *Scheduler {
	return &Scheduler{
		cfg:      cfg,
		jobs:     jobs,
		pub:      pub,
		db:       store,
		statuses: make(map[uint64]model.Status),
	}
}

func (s *Scheduler) add(st model.Status) {
	s.mu.Lock()
	s.statuses[st.ID] = st
	s.mu.Unlock()
}

// Run blocks forever; start it in its own goroutine.
func (s *Scheduler) Run() {
	// Collect URLs registered while the server is running.
	go func() {
		for st := range s.jobs {
			s.add(st)
		}
	}()

	// Restore URLs from the database so a restart does not stop monitoring.
	if existing, err := s.db.All(); err != nil {
		log.Printf("scheduler: could not load existing urls: %v", err)
	} else {
		for _, st := range existing {
			s.add(st)
		}
		log.Printf("scheduler: restored %d monitored urls", len(existing))
	}

	ticker := time.NewTicker(time.Duration(s.cfg.Common.Period) * time.Second)
	defer ticker.Stop()
	for range ticker.C {
		s.publishAll()
	}
}

func (s *Scheduler) publishAll() {
	s.mu.RLock()
	batch := make([]model.Status, 0, len(s.statuses))
	for _, st := range s.statuses {
		batch = append(batch, st)
	}
	s.mu.RUnlock()

	for i := range batch {
		if err := s.pub.Publish(&batch[i]); err != nil {
			log.Printf("scheduler: publish of status %d failed: %v", batch[i].ID, err)
		}
	}
}
