package scheduler

import (
	"sort"
	"sync"
	"testing"

	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
)

type fakePub struct {
	mu  sync.Mutex
	ids []uint64
}

func (f *fakePub) Publish(s *model.Status) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.ids = append(f.ids, s.ID)
	return nil
}

func TestPublishAllSendsEachStatusOnce(t *testing.T) {
	pub := &fakePub{}
	s := New(config.Config{}, make(chan model.Status), pub, nil)

	s.add(model.Status{ID: 1})
	s.add(model.Status{ID: 2})
	s.add(model.Status{ID: 2}) // duplicate id must not be published twice
	s.publishAll()

	sort.Slice(pub.ids, func(i, j int) bool { return pub.ids[i] < pub.ids[j] })
	if len(pub.ids) != 2 || pub.ids[0] != 1 || pub.ids[1] != 2 {
		t.Fatalf("published %v, want [1 2]", pub.ids)
	}
}
