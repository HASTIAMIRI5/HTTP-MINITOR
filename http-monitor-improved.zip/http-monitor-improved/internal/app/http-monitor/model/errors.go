package model

import "errors"

// ErrNotFound is returned by the data layer when a record does not exist.
var ErrNotFound = errors.New("record not found")
