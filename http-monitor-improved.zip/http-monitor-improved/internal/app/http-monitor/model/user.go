package model

type User struct {
	Username string `gorm:"primaryKey"`
	Password string `gorm:"not null"` // bcrypt hash, never the plain password
}

func NewUser(username string, passwordHash string) *User {
	return &User{Username: username, Password: passwordHash}
}

type UserI interface {
	GetUser(username string) (User, error)
	Register(user *User) error
}
