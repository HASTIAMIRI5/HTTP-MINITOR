package model

import (
	"time"

	"github.com/lib/pq"
)

type Status struct {
	ID         uint64 `gorm:"primaryKey;auto_increment"`
	Username   string `gorm:"not null"`
	Url        uint64
	StatusCode pq.Int32Array `gorm:"type:int[]"`
	Time       time.Time     // time of the last completed check
}

func NewStatus(username string, url uint64) *Status {
	return &Status{Username: username, Url: url}
}

// IsSuccess reports whether a recorded code counts as a healthy response.
// 0 is recorded when the request itself failed (timeout, DNS, refused...).
func IsSuccess(code int32) bool {
	return code >= 200 && code < 300
}

// AddResults appends new codes and keeps only the newest `window` entries,
// so the history (and the alert counting) never grows without bound.
func (s *Status) AddResults(codes []int32, window int) {
	all := append(append([]int32{}, s.StatusCode...), codes...)
	if window > 0 && len(all) > window {
		all = all[len(all)-window:]
	}
	s.StatusCode = pq.Int32Array(all)
}

// Failures counts the unhealthy results inside the current window.
func (s Status) Failures() int {
	n := 0
	for _, c := range s.StatusCode {
		if !IsSuccess(c) {
			n++
		}
	}
	return n
}

// Codes returns the history as a non-nil slice (so JSON shows [] instead of null).
func (s Status) Codes() []int32 {
	if s.StatusCode == nil {
		return []int32{}
	}
	return []int32(s.StatusCode)
}

type StatusI interface {
	Record(status *Status) error
	Search(username string) ([]Status, error)
	All() ([]Status, error)
	Update(status *Status) error
	GetFirst(id uint64) (Status, error)
}
