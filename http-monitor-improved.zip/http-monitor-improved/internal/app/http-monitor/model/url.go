package model

// DefaultThreshold is used when the client does not send a threshold.
const DefaultThreshold = 5

type Url struct {
	ID        uint64 `gorm:"primaryKey;auto_increment"`
	Body      string `gorm:"not null"`
	Threshold int    `gorm:"default:5"`
}

func NewUrl(body string, threshold int) *Url {
	return &Url{Body: body, Threshold: threshold}
}

type UrlI interface {
	AddUrl(url *Url) error
	SearchUrl(id uint64) (Url, error)
}
