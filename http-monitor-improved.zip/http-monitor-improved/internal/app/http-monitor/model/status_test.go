package model

import (
	"reflect"
	"testing"
)

func TestAddResultsKeepsOnlyTheWindow(t *testing.T) {
	s := &Status{}
	s.AddResults([]int32{200, 200, 500}, 5)
	s.AddResults([]int32{404, 200, 200}, 5)

	want := []int32{200, 500, 404, 200, 200}
	if got := s.Codes(); !reflect.DeepEqual(got, want) {
		t.Fatalf("got %v, want %v", got, want)
	}
}

func TestFailuresCountsEverythingExceptSuccess(t *testing.T) {
	s := &Status{}
	s.AddResults([]int32{200, 204, 301, 404, 500, 0}, 100)
	if got := s.Failures(); got != 4 { // 301, 404, 500, 0
		t.Fatalf("got %d failures, want 4", got)
	}
}

func TestCodesIsNeverNil(t *testing.T) {
	if (Status{}).Codes() == nil {
		t.Fatal("Codes() must return an empty slice, not nil")
	}
}
