package request

import (
	"errors"
	"strings"
)

type User struct {
	Username string `json:"name"`
	Password string `json:"password"`
}

func NewUser(username string, password string) *User {
	return &User{Username: username, Password: password}
}

// ValidateNew checks the rules for a brand-new account.
func (u *User) ValidateNew() error {
	u.Username = strings.TrimSpace(u.Username)
	switch {
	case u.Username == "":
		return errors.New("name is required")
	case len(u.Username) > 64:
		return errors.New("name must be at most 64 characters")
	case len(u.Password) < 8:
		return errors.New("password must be at least 8 characters")
	case len(u.Password) > 72: // bcrypt only uses the first 72 bytes
		return errors.New("password must be at most 72 bytes")
	}
	return nil
}
