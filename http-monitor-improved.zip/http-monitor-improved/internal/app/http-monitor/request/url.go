package request

import (
	"errors"
	"net/url"
)

type Url struct {
	UrlBody   string `json:"url"`
	Threshold int    `json:"threshold"`
}

func NewUrl(body string, threshold int) *Url {
	return &Url{UrlBody: body, Threshold: threshold}
}

// ValidateBody checks that the address is a usable http(s) URL.
func (u *Url) ValidateBody() error {
	if u.UrlBody == "" {
		return errors.New("url is required")
	}
	if len(u.UrlBody) > 2048 {
		return errors.New("url is too long")
	}
	parsed, err := url.Parse(u.UrlBody)
	if err != nil {
		return errors.New("url is not valid")
	}
	if parsed.Scheme != "http" && parsed.Scheme != "https" {
		return errors.New("url must start with http:// or https://")
	}
	if parsed.Hostname() == "" {
		return errors.New("url has no host")
	}
	return nil
}

// ValidateThreshold applies the default and checks the upper bound
// (a threshold above the history window could never trigger an alert).
func (u *Url) ValidateThreshold(defaultValue, max int) error {
	if u.Threshold == 0 {
		u.Threshold = defaultValue
	}
	if u.Threshold < 1 || u.Threshold > max {
		return errors.New("threshold must be between 1 and the history window size")
	}
	return nil
}
