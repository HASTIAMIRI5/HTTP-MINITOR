package request

import "testing"

func TestValidateBody(t *testing.T) {
	cases := map[string]bool{
		"https://example.com":      true,
		"http://example.com/a?b=1": true,
		"":                         false,
		"example.com":              false,
		"ftp://example.com":        false,
		"http://":                  false,
	}
	for in, ok := range cases {
		err := (&Url{UrlBody: in}).ValidateBody()
		if (err == nil) != ok {
			t.Errorf("ValidateBody(%q): err=%v, want ok=%v", in, err, ok)
		}
	}
}

func TestValidateThreshold(t *testing.T) {
	u := &Url{}
	if err := u.ValidateThreshold(5, 100); err != nil || u.Threshold != 5 {
		t.Fatalf("zero threshold should become the default, got %d / %v", u.Threshold, err)
	}
	if err := (&Url{Threshold: -1}).ValidateThreshold(5, 100); err == nil {
		t.Error("negative threshold must be rejected")
	}
	if err := (&Url{Threshold: 101}).ValidateThreshold(5, 100); err == nil {
		t.Error("threshold above the window must be rejected")
	}
}

func TestValidateNewUser(t *testing.T) {
	if err := (&User{Username: "ali", Password: "short"}).ValidateNew(); err == nil {
		t.Error("short password must be rejected")
	}
	if err := (&User{Username: "  ", Password: "longenough1"}).ValidateNew(); err == nil {
		t.Error("blank name must be rejected")
	}
	if err := (&User{Username: "ali", Password: "longenough1"}).ValidateNew(); err != nil {
		t.Errorf("valid user rejected: %v", err)
	}
}
