package config

// insecureSecret is the placeholder JWT secret. Config.Validate refuses to
// start the server with it unless HTTP_MONITOR_JWT_SECRET overrides it.
const insecureSecret = "change-me-in-production"

const defaultConfig = `
server:
  address: :21345
jwt:
  secret: ` + insecureSecret + `
  expiration: 60
nats:
  host: nats://localhost:4222
  topic: url
  name: httpMonitor
database:
  path: HttpMDB.db
common:
  period: 3
  requests: 10
  timeout: 10
  window: 100
  workers: 20
`
