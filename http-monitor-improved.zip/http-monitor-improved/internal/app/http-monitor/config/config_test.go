package config

import (
	"os"
	"testing"
)

func TestDefaultsAreValidButSecretMustBeSet(t *testing.T) {
	os.Unsetenv("HTTP_MONITOR_JWT_SECRET")
	cfg := Init()
	if err := cfg.Validate(); err != nil {
		t.Fatalf("defaults should be valid: %v", err)
	}
	if err := cfg.RequireSecureSecret(); err == nil {
		t.Fatal("the placeholder secret must be rejected")
	}
}

func TestEnvOverridesSecret(t *testing.T) {
	os.Setenv("HTTP_MONITOR_JWT_SECRET", "a-long-random-secret")
	defer os.Unsetenv("HTTP_MONITOR_JWT_SECRET")

	cfg := Init()
	if err := cfg.RequireSecureSecret(); err != nil {
		t.Fatalf("secret from env should be accepted: %v", err)
	}
}
