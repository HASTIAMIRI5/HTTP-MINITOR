package config

import (
	"bytes"
	"errors"
	"log"
	"strings"

	"github.com/spf13/viper"
)

const cfgPrefix = "http-monitor"

type (
	Config struct {
		JWT      JWT      `mapstructure:"jwt"`
		Server   Server   `mapstructure:"server"`
		Nats     Nats     `mapstructure:"nats"`
		Database Database `mapstructure:"database"`
		Common   Common   `mapstructure:"common"`
	}

	JWT struct {
		Secret     string `mapstructure:"secret"`
		Expiration int    `mapstructure:"expiration"` // minutes
	}

	Server struct {
		Address string `mapstructure:"address"`
	}

	Nats struct {
		Host  string `mapstructure:"host"`
		Topic string `mapstructure:"topic"`
		Name  string `mapstructure:"name"`
	}

	Database struct {
		Path string `mapstructure:"path"`
	}

	Common struct {
		Period   int `mapstructure:"period"`   // seconds between two monitoring rounds
		Requests int `mapstructure:"requests"` // HTTP requests per round per URL
		Timeout  int `mapstructure:"timeout"`  // seconds, per HTTP request
		Window   int `mapstructure:"window"`   // how many recent results are kept / counted
		Workers  int `mapstructure:"workers"`  // max URLs a worker checks at the same time
	}
)

// Validate checks that the configuration is usable.
func (c Config) Validate() error {
	switch {
	case c.JWT.Expiration <= 0:
		return errors.New("jwt.expiration must be > 0")
	case c.Common.Period <= 0:
		return errors.New("common.period must be > 0")
	case c.Common.Requests <= 0:
		return errors.New("common.requests must be > 0")
	case c.Common.Timeout <= 0:
		return errors.New("common.timeout must be > 0")
	case c.Common.Window < c.Common.Requests:
		return errors.New("common.window must be >= common.requests")
	case c.Common.Workers <= 0:
		return errors.New("common.workers must be > 0")
	case c.Database.Path == "":
		return errors.New("database.path must not be empty")
	}
	return nil
}

// RequireSecureSecret fails if the JWT secret is still the built-in placeholder.
// Only the server signs tokens, so only the server calls this.
func (c Config) RequireSecureSecret() error {
	if c.JWT.Secret == "" || c.JWT.Secret == insecureSecret {
		return errors.New("jwt.secret is not set: export HTTP_MONITOR_JWT_SECRET with a long random value")
	}
	return nil
}

// Init loads the defaults and lets environment variables override them,
// e.g. HTTP_MONITOR_JWT_SECRET or HTTP_MONITOR_SERVER_ADDRESS.
func Init() Config {
	v := viper.New()
	v.SetConfigType("yaml")

	if err := v.ReadConfig(bytes.NewReader([]byte(defaultConfig))); err != nil {
		log.Fatalf("error loading default configs: %s", err.Error())
	}
	v.SetEnvPrefix(cfgPrefix)
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_", "-", "_"))
	v.AutomaticEnv()

	var cfg Config
	if err := v.UnmarshalExact(&cfg); err != nil {
		log.Fatalf("failed to unmarshal config into struct: %s", err.Error())
	}
	if err := cfg.Validate(); err != nil {
		log.Fatalf("invalid config: %s", err.Error())
	}
	return cfg
}
