package handler

import (
	"log"
	"net/http"

	"github.com/labstack/echo/v4"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/request"
)

type UrlHandler struct {
	Cfg     config.Config
	StatusI model.StatusI
	UrlI    model.UrlI
	Jobs    chan model.Status
}

// Send registers a new URL for the authenticated user (route is behind the auth middleware).
func (h *UrlHandler) Send(c echo.Context) error {
	req := new(request.Url)
	if err := c.Bind(req); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody("invalid request body"))
	}
	if err := req.ValidateBody(); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody(err.Error()))
	}
	if err := req.ValidateThreshold(model.DefaultThreshold, h.Cfg.Common.Window); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody(err.Error()))
	}

	username := currentUser(c)

	existing, err := h.StatusI.Search(username)
	if err != nil {
		log.Printf("send: search failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	for _, s := range existing {
		u, err := h.UrlI.SearchUrl(s.Url)
		if err == nil && u.Body == req.UrlBody {
			return c.JSON(http.StatusConflict, errorBody("this url is already being monitored"))
		}
	}

	url := model.NewUrl(req.UrlBody, req.Threshold)
	if err := h.UrlI.AddUrl(url); err != nil {
		log.Printf("send: add url failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}

	status := model.NewStatus(username, url.ID)
	if err := h.StatusI.Record(status); err != nil {
		log.Printf("send: record failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}

	h.Jobs <- *status

	return c.JSON(http.StatusCreated, map[string]interface{}{
		"url":       url.Body,
		"threshold": url.Threshold,
	})
}
