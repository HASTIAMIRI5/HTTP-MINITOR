package handler

import (
	"log"
	"net/http"

	"github.com/labstack/echo/v4"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/request"
)

type ResponseHandler struct {
	StatusI model.StatusI
	UrlI    model.UrlI
}

type entry struct {
	url    model.Url
	status model.Status
}

// entries returns the user's monitored URLs together with their status rows.
// Everything is filtered by the authenticated username.
func (h *ResponseHandler) entries(username string) ([]entry, error) {
	statuses, err := h.StatusI.Search(username)
	if err != nil {
		return nil, err
	}
	result := make([]entry, 0, len(statuses))
	for _, s := range statuses {
		// s.Url is the id of the Url row (not s.ID, the id of the status row)
		u, err := h.UrlI.SearchUrl(s.Url)
		if err != nil {
			log.Printf("response: url %d for status %d: %v", s.Url, s.ID, err)
			continue
		}
		result = append(result, entry{url: u, status: s})
	}
	return result, nil
}

// Get returns {url: [status codes...]} for all URLs of the user.
func (h *ResponseHandler) Get(c echo.Context) error {
	items, err := h.entries(currentUser(c))
	if err != nil {
		log.Printf("get: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	out := make(map[string][]int32, len(items))
	for _, it := range items {
		out[it.url.Body] = it.status.Codes()
	}
	return c.JSON(http.StatusOK, out)
}

// Post returns the status codes of a single URL: body {"url": "..."}.
func (h *ResponseHandler) Post(c echo.Context) error {
	req := new(request.Url)
	if err := c.Bind(req); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody("invalid request body"))
	}
	if req.UrlBody == "" {
		return c.JSON(http.StatusBadRequest, errorBody("url is required"))
	}

	items, err := h.entries(currentUser(c))
	if err != nil {
		log.Printf("post: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	for _, it := range items {
		if it.url.Body == req.UrlBody {
			return c.JSON(http.StatusOK, map[string][]int32{it.url.Body: it.status.Codes()})
		}
	}
	return c.JSON(http.StatusNotFound, errorBody("url is not monitored by this user"))
}

// Alert returns {url: true} for every URL whose failures in the recent window
// reached its threshold.
func (h *ResponseHandler) Alert(c echo.Context) error {
	items, err := h.entries(currentUser(c))
	if err != nil {
		log.Printf("alert: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	out := make(map[string]bool)
	for _, it := range items {
		failures := it.status.Failures()
		if failures > 0 && failures >= it.url.Threshold {
			out[it.url.Body] = true
		}
	}
	return c.JSON(http.StatusOK, out)
}
