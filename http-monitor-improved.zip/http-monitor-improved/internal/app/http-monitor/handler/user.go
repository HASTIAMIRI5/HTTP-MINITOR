package handler

import (
	"errors"
	"log"
	"net/http"
	"strings"

	"github.com/labstack/echo/v4"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/request"
	"golang.org/x/crypto/bcrypt"
)

type UserHandler struct {
	UserI model.UserI
	Token *Token
}

func (h *UserHandler) Register(c echo.Context) error {
	req := new(request.User)
	if err := c.Bind(req); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody("invalid request body"))
	}
	if err := req.ValidateNew(); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody(err.Error()))
	}

	_, err := h.UserI.GetUser(req.Username)
	if err == nil {
		return c.JSON(http.StatusConflict, errorBody("username already taken"))
	}
	if !errors.Is(err, model.ErrNotFound) {
		log.Printf("register: lookup failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		log.Printf("register: hashing failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}

	user := model.NewUser(req.Username, string(hash))
	if err := h.UserI.Register(user); err != nil {
		// most likely a concurrent registration of the same name
		log.Printf("register: create failed: %v", err)
		return c.JSON(http.StatusConflict, errorBody("could not create user"))
	}

	token, err := h.Token.GenerateJWT(*user)
	if err != nil {
		log.Printf("register: token failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	return c.JSON(http.StatusCreated, map[string]string{"token": token})
}

func (h *UserHandler) Login(c echo.Context) error {
	req := new(request.User)
	if err := c.Bind(req); err != nil {
		return c.JSON(http.StatusBadRequest, errorBody("invalid request body"))
	}

	user, err := h.UserI.GetUser(strings.TrimSpace(req.Username))
	if err != nil {
		if errors.Is(err, model.ErrNotFound) {
			return c.JSON(http.StatusUnauthorized, errorBody("wrong name or password"))
		}
		log.Printf("login: lookup failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
		return c.JSON(http.StatusUnauthorized, errorBody("wrong name or password"))
	}

	token, err := h.Token.GenerateJWT(user)
	if err != nil {
		log.Printf("login: token failed: %v", err)
		return c.JSON(http.StatusInternalServerError, errorBody("internal error"))
	}
	return c.JSON(http.StatusOK, map[string]string{"token": token})
}
