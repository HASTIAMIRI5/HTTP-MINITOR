package handler

import (
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/dgrijalva/jwt-go"
	"github.com/labstack/echo/v4"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
)

const usernameKey = "username"

type Token struct {
	Cfg config.Config
}

func (t *Token) GenerateJWT(user model.User) (string, error) {
	token := jwt.New(jwt.SigningMethodHS256)
	claims := token.Claims.(jwt.MapClaims)
	claims["username"] = user.Username
	claims["exp"] = time.Now().Add(time.Duration(t.Cfg.JWT.Expiration) * time.Minute).Unix()
	return token.SignedString([]byte(t.Cfg.JWT.Secret))
}

// Parse validates the signature and expiry and returns the username inside.
func (t *Token) Parse(raw string) (string, error) {
	claims := jwt.MapClaims{}
	parsed, err := jwt.ParseWithClaims(raw, claims, func(tk *jwt.Token) (interface{}, error) {
		if _, ok := tk.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method %v", tk.Header["alg"])
		}
		return []byte(t.Cfg.JWT.Secret), nil
	})
	if err != nil {
		return "", err
	}
	if !parsed.Valid {
		return "", errors.New("invalid token")
	}
	username, ok := claims["username"].(string)
	if !ok || username == "" {
		return "", errors.New("token has no username")
	}
	return username, nil
}

// Middleware rejects requests without a valid token (401) and stores the
// username in the request context. The token is read from the "Token" header,
// or from "Authorization: Bearer <token>".
func (t *Token) Middleware() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			raw := c.Request().Header.Get("Token")
			if raw == "" {
				raw = strings.TrimPrefix(c.Request().Header.Get("Authorization"), "Bearer ")
			}
			if raw == "" {
				return c.JSON(http.StatusUnauthorized, errorBody("missing token"))
			}
			username, err := t.Parse(raw)
			if err != nil {
				return c.JSON(http.StatusUnauthorized, errorBody("invalid or expired token"))
			}
			c.Set(usernameKey, username)
			return next(c)
		}
	}
}

func currentUser(c echo.Context) string {
	u, _ := c.Get(usernameKey).(string)
	return u
}

func errorBody(msg string) map[string]string {
	return map[string]string{"error": msg}
}
