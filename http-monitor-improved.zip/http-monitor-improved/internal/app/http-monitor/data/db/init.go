package db

import (
	"fmt"

	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

// NewDB opens the SQLite file. The server and the worker share it, so we use
// WAL mode and a busy timeout to avoid "database is locked" errors.
func NewDB(path string) (*gorm.DB, error) {
	dsn := path + "?_busy_timeout=5000&_journal_mode=WAL"
	return gorm.Open(sqlite.Open(dsn), &gorm.Config{})
}

func migrate(db *gorm.DB) error {
	return db.AutoMigrate(&model.User{}, &model.Url{}, &model.Status{})
}

func Init(path string) (*gorm.DB, error) {
	db, err := NewDB(path)
	if err != nil {
		return nil, fmt.Errorf("open database %q: %w", path, err)
	}
	if err = migrate(db); err != nil {
		return nil, fmt.Errorf("migrate database: %w", err)
	}
	return db, nil
}
