package db

import (
	"errors"

	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
	"gorm.io/gorm"
)

type Mydb struct {
	DB *gorm.DB
}

// notFound maps GORM's error to the data-layer-independent model.ErrNotFound.
func notFound(err error) error {
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return model.ErrNotFound
	}
	return err
}

// NOTE: every query uses explicit "col = ?" conditions. Passing a struct to
// Where() makes GORM silently skip zero-value fields (e.g. an empty username),
// which turns a filter into "match everything".

func (d *Mydb) GetUser(username string) (model.User, error) {
	var stored model.User
	err := d.DB.Where("username = ?", username).First(&stored).Error
	return stored, notFound(err)
}

func (d *Mydb) Register(user *model.User) error {
	return d.DB.Create(user).Error
}

func (d *Mydb) AddUrl(url *model.Url) error {
	return d.DB.Create(url).Error
}

func (d *Mydb) SearchUrl(id uint64) (model.Url, error) {
	var stored model.Url
	err := d.DB.Where("id = ?", id).First(&stored).Error
	return stored, notFound(err)
}

func (d *Mydb) Record(status *model.Status) error {
	return d.DB.Create(status).Error
}

func (d *Mydb) Search(username string) ([]model.Status, error) {
	var stored []model.Status
	err := d.DB.Where("username = ?", username).Find(&stored).Error
	return stored, err
}

func (d *Mydb) All() ([]model.Status, error) {
	var stored []model.Status
	err := d.DB.Find(&stored).Error
	return stored, err
}

func (d *Mydb) Update(status *model.Status) error {
	return d.DB.Save(status).Error
}

func (d *Mydb) GetFirst(id uint64) (model.Status, error) {
	var stored model.Status
	err := d.DB.Where("id = ?", id).First(&stored).Error
	return stored, notFound(err)
}
