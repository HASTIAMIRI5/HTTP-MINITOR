package nats

import (
	"fmt"

	"github.com/nats-io/nats.go"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
)

// New connects to NATS and makes sure the JetStream stream exists.
// Creating a stream that already exists with the same config is a no-op.
func New(cfg config.Config) (nats.JetStreamContext, error) {
	nc, err := nats.Connect(cfg.Nats.Host)
	if err != nil {
		return nil, fmt.Errorf("connect to NATS at %s: %w", cfg.Nats.Host, err)
	}

	js, err := nc.JetStream()
	if err != nil {
		return nil, fmt.Errorf("enable JetStream (is nats-server started with -js?): %w", err)
	}

	if _, err := js.StreamInfo(cfg.Nats.Name); err != nil {
		_, err = js.AddStream(&nats.StreamConfig{
			Name:     cfg.Nats.Name,
			Subjects: []string{cfg.Nats.Topic},
		})
		if err != nil {
			return nil, fmt.Errorf("create stream %q: %w", cfg.Nats.Name, err)
		}
	}
	return js, nil
}
