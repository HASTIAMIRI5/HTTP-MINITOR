package nats

import (
	"encoding/json"
	"log"

	"github.com/nats-io/nats.go"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/config"
	"github.com/shirinebadi/http-monitor/internal/app/http-monitor/model"
)

const consumerName = "monitor"

type Nats struct {
	Cfg config.Config
	Cn  nats.JetStreamContext
}

// Publish sends one status to the workers.
func (n *Nats) Publish(s *model.Status) error {
	data, err := json.Marshal(s)
	if err != nil {
		return err
	}
	_, err = n.Cn.Publish(n.Cfg.Nats.Topic, data)
	return err
}

// Subscribe registers handle for every message. The message is acknowledged
// only when handle calls done(), so a worker that crashes mid-check does not
// lose the job. Workers share one queue group, so several can run in parallel
// and each message goes to just one of them.
func (n *Nats) Subscribe(handle func(s *model.Status, done func())) (*nats.Subscription, error) {
	return n.Cn.QueueSubscribe(n.Cfg.Nats.Topic, consumerName, func(msg *nats.Msg) {
		var s model.Status
		if err := json.Unmarshal(msg.Data, &s); err != nil {
			log.Printf("nats: dropping malformed message: %v", err)
			_ = msg.Ack()
			return
		}
		handle(&s, func() {
			if err := msg.Ack(); err != nil {
				log.Printf("nats: ack failed: %v", err)
			}
		})
	}, nats.Durable(consumerName), nats.ManualAck())
}
