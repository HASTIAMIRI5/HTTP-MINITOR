# What changed (and why)

## Security
* Passwords are stored as **bcrypt hashes** (was plain text).
* Register no longer issues a token for an already existing name (was an account takeover) – returns 409.
* Login always checks the password (GORM used to drop an empty password from the query).
* A **token middleware** protects `/request`, `/result`, `/result/url`, `/alerts`.
  Invalid/missing token → 401 (was: empty username → every user's data was returned).
* JWT secret must come from `HTTP_MONITOR_JWT_SECRET`; the server won't start with the placeholder.
* All queries use `Where("col = ?", v)` instead of struct conditions.
* URL validation (http/https only), body size limit (1 MiB), input validation for name/password.

## Bugs
* `/result/url` works (was binding into a string).
* URL lookup uses `status.Url` (was `status.ID`).
* History is capped to `common.window` results, so alerts reflect recent behaviour instead of all-time totals.
* Duplicate URLs for the same user are rejected (409).

## Concurrency / reliability
* Worker: one `WaitGroup`-synchronised probe round, one DB write per round (was 10 racing writes),
  HTTP timeout, response bodies closed, bounded parallelism, graceful shutdown.
* Message is acked **after** results are saved; overlapping rounds for the same URL are skipped.
* Scheduler: mutex-protected map, restores URLs from the DB on start, no more `log.Fatal` on publish errors.
* NATS/DB errors are returned and reported instead of being ignored.
* Workers join one queue group, so several workers can run side by side.
* SQLite uses WAL + busy timeout (server and worker share the file).

## Cleanup
* Config: env prefix `HTTP_MONITOR_`, manual `Validate()`, removed debug `print`, new keys documented.
* Removed unused `model/request.go`, README examples fixed, tests added.

## Behaviour changes to know about
* Old databases contain plain-text passwords → delete `HttpMDB.db` (users must register again).
* Failed requests are recorded as `0` (was `500`); only 2xx counts as healthy.
* `/register` returns 201 and `/request` returns 201 with a JSON body.

## Still not done
* No way to delete/pause a monitored URL.
* No SSRF protection (users can make the worker call internal addresses).
* The `dgrijalva/jwt-go` library is deprecated (kept to avoid new dependencies).
* Multiple workers can still process the same URL at the same time (the overlap guard is per worker).
* **Not compiled or run** – see below.
