module github.com/shirinebadi/http-monitor

go 1.16

require (
	github.com/dgrijalva/jwt-go v3.2.0+incompatible
	github.com/go-playground/universal-translator v0.18.0 // indirect
	github.com/labstack/echo/v4 v4.5.0
	github.com/labstack/gommon v0.3.0 // indirect
	github.com/leodido/go-urn v1.2.1 // indirect
	github.com/lib/pq v1.10.2
	github.com/nats-io/nats.go v1.11.0 // indirect
	github.com/spf13/cobra v1.2.1
	github.com/spf13/viper v1.8.1 // indirect
	golang.org/x/crypto v0.0.0-20210322153248-0c34fe9e7dc2
	gopkg.in/go-playground/validator.v9 v9.31.0
	gorm.io/driver/sqlite v1.1.4
	gorm.io/gorm v1.21.13

)
